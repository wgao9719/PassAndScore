Boost.Python NumPy extension Reference
======================================

.. toctree::
   :maxdepth: 2

   dtype
   ndarray
   unary_ufunc
   binary_ufunc
   multi_iter

